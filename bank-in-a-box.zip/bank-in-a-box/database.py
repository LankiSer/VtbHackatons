"""
Database connection and session management
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from typing import AsyncGenerator
import os

# Database URL from environment
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://hackapi_user:hackapi_pass@localhost:5432/bank_db"
)

# Convert to async URL if needed
if DATABASE_URL.startswith("postgresql://"):
    ASYNC_DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://")
else:
    ASYNC_DATABASE_URL = DATABASE_URL

# Create async engine
try:
    engine = create_async_engine(ASYNC_DATABASE_URL, echo=True)
    # Убеждаемся что engine создан
    if engine is None:
        raise RuntimeError("Failed to create database engine - engine is None")
except Exception as e:
    import traceback
    print(f"Error creating database engine: {e}")
    print(f"DATABASE_URL: {DATABASE_URL}")
    print(f"ASYNC_DATABASE_URL: {ASYNC_DATABASE_URL}")
    traceback.print_exc()
    raise

# Проверяем что engine доступен для импорта
if 'engine' not in globals():
    raise RuntimeError("engine variable not created in database module")

# Create async session maker
AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False
)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency для получения database session
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# Явно экспортируем engine для импорта
__all__ = ['engine', 'AsyncSessionLocal', 'get_db']

