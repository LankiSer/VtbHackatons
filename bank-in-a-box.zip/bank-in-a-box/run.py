"""
Точка входа для запуска Bank-in-a-Box

Используется для корректной работы относительных импортов
"""
import sys
import os
from pathlib import Path

# Устанавливаем рабочую директорию и PYTHONPATH
root_dir = Path(__file__).parent.absolute()
os.chdir(root_dir)
sys.path.insert(0, str(root_dir))
os.environ['PYTHONPATH'] = str(root_dir)

# КРИТИЧЕСКИ ВАЖНО: Патчим __import__ ПЕРЕД всеми остальными импортами!
# Это преобразует относительные импорты (from ..database) в абсолютные (from database)
_original_import = __import__

def _patched_import(name, globals=None, locals=None, fromlist=(), level=0):
    """Преобразует относительные импорты в абсолютные для работы вне пакетов"""
    # Абсолютные импорты - работаем как обычно
    if level == 0:
        return _original_import(name, globals, locals, fromlist, level)
    
    # Относительные импорты (level > 0) - преобразуем ТОЛЬКО для наших api модулей
    caller_name = None
    caller_file = None
    if globals:
        caller_name = globals.get('__name__') or globals.get('__package__')
        caller_file = globals.get('__file__', '')
    
    # Проверяем, что это наш модуль из проекта (не системный)
    is_our_module = False
    if caller_file:
        caller_file_str = str(caller_file).replace('\\', '/')
        # Файл должен быть в /app/ (наш проект)
        if '/app/' in caller_file_str:
            is_our_module = True
        # Если файл НЕ в /app/, это системный модуль - НЕ ТРОГАЕМ
        else:
            return _original_import(name, globals, locals, fromlist, level)
    elif caller_name:
        # Проверяем по имени модуля - если это не стандартная библиотека
        if caller_name and not caller_name.startswith(('asyncio', 'uvicorn', 'fastapi', 'pydantic', 'sqlalchemy')):
            # Скорее всего наш модуль
            is_our_module = True
    
    # Если это наш модуль, преобразуем относительный импорт в абсолютный
    if is_our_module:
        # Строим абсолютное имя модуля из относительного
        # Если caller_name = "api.accounts", то:
        #   ..database (level=1) -> database
        #   ..services.auth_service (level=2) -> services.auth_service
        if caller_name:
            # Извлекаем package части (убираем последние level частей)
            parts = caller_name.split('.')
            # Убираем level частей снизу
            base_parts = parts[:-level] if len(parts) >= level else []
            # Строим абсолютное имя
            if name:
                # Есть имя модуля (например, ..services -> services)
                absolute_name = '.'.join(base_parts + [name]) if base_parts else name
            else:
                # Нет имени (from .. import X) - используем base_parts
                absolute_name = '.'.join(base_parts) if base_parts else ''
        else:
            # Нет caller_name - просто используем name как абсолютное
            absolute_name = name if name else ''
        
        # Вызываем с абсолютным именем и level=0
        return _original_import(absolute_name, globals, locals, fromlist, 0)
    
    # Для всех остальных - не трогаем
    return _original_import(name, globals, locals, fromlist, level)

# Устанавливаем патч ПЕРЕД любыми другими импортами
import builtins
builtins.__import__ = _patched_import

# Импортируем и запускаем приложение
if __name__ == "__main__":
    import uvicorn
    import types
    
    # Пробуем импортировать app напрямую
    # main.py должен использовать абсолютные импорты (из except ImportError)
    try:
        import main
        app = main.app
        config = main.config
    except ImportError as e:
        print(f"Ошибка импорта main: {e}")
        import traceback
        traceback.print_exc()
        raise
    
    # Определяем порт на основе bank_code
    port_map = {
        "vbank": 8001,
        "abank": 8002,
        "sbank": 8003
    }
    port = port_map.get(config.BANK_CODE, 8000)
    
    print(f"🏦 Starting {config.BANK_NAME} on port {port}")
    print(f"📍 Swagger UI: http://localhost:{port}/docs")
    print(f"📍 Client UI: http://localhost:{port}/client/")
    
    # Запускаем uvicorn с объектом app напрямую
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=port,
        reload=False,
        log_level="info"
    )

