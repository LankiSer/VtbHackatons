-- Добавление таблицы teams и команды team200
-- Этот скрипт можно выполнить в уже работающих контейнерах

-- Создание таблицы teams (если её еще нет)
CREATE TABLE IF NOT EXISTS teams (
    id SERIAL PRIMARY KEY,
    client_id VARCHAR(100) UNIQUE NOT NULL,
    client_secret VARCHAR(255) NOT NULL,
    team_name VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Добавление команды team200 (пример для документации)
INSERT INTO teams (client_id, client_secret, team_name, is_active) VALUES
('team200', '5OAaa4DYzYKfnOU6zbR34ic5qMm7VSMB', 'Команда 200 (пример)', true)
ON CONFLICT (client_id) DO NOTHING;

